"use client"

export default function About() {
  return (
    <section id="about" className="min-h-screen flex items-center py-20 px-6 relative">
      <div className="max-w-7xl w-full mx-auto">
        <div className="space-y-12">
          {/* Section Title */}
          <div className="text-center space-y-4">
            <h2 className="text-5xl md:text-6xl font-bold text-white">
              About <span className="text-purple-400">Me</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-cyan-500 mx-auto"></div>
          </div>

          {/* Bio */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 fade-in-up">
              <p className="text-lg text-gray-300 leading-relaxed">
                I'm <strong>Yuvraj Razdan</strong>, a first-year Computer Engineering student passionate about
                technology and innovation. My journey began with curiosity about how things work, leading me to explore
                web development, artificial intelligence, machine learning, and cybersecurity.
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">
                Currently, I'm honing my skills in Python and C while experimenting with MATLAB, particularly in
                Agri-Tech applications. I believe in continuous learning and staying updated with emerging technologies.
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">
                Beyond coding, I'm an enthusiast of football, basketball, and Formula racing—activities that fuel my
                passion and help me think creatively about problem-solving.
              </p>
            </div>

            {/* Timeline */}
            <div className="space-y-6 fade-in-up" style={{ animationDelay: "0.2s" }}>
              <div className="neon-box p-6 rounded-xl backdrop-blur border border-purple-500/30">
                <h3 className="text-2xl font-bold text-purple-400 mb-4">Education</h3>
                <div className="space-y-4">
                  <div className="border-l-2 border-cyan-500 pl-4">
                    <h4 className="text-lg font-semibold text-white">High School (12th Grade)</h4>
                    <p className="text-gray-400">Graduation Year: 2025</p>
                  </div>
                  <div className="border-l-2 border-purple-500 pl-4">
                    <h4 className="text-lg font-semibold text-white">Computer Engineering</h4>
                    <p className="text-gray-400">Currently Pursuing</p>
                  </div>
                </div>
              </div>

              <div className="neon-box p-6 rounded-xl backdrop-blur border border-purple-500/30">
                <h3 className="text-2xl font-bold text-cyan-400 mb-4">Experience</h3>
                <ul className="space-y-2 text-gray-300">
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-cyan-500 rounded-full"></span>
                    Student Council Member
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-cyan-500 rounded-full"></span>
                    NGO Work (Social Impact)
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-cyan-500 rounded-full"></span>
                    Startup Marketing
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
