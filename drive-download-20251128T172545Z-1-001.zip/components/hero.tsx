"use client"

import { useState, useEffect } from "react"
import { ChevronDown } from "lucide-react"

export default function Hero() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  // Array of image URLs with proper source URLs
  const images = [
    "/images/image.png",
    "/images/2.jpg",
    "/images/3.jpg",
    "/images/4.jpg",
    "/images/5.jpg",
    "/images/6.jpg",
    "/images/7.jpg",
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % images.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-20 px-6 relative">
      <div className="max-w-7xl w-full mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-6 slide-in-left">
            <div className="space-y-2">
              <h1 className="text-6xl md:text-7xl font-bold text-white leading-tight">
                Yuvraj
                <br />
                <span className="bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-500 bg-clip-text text-transparent neon-text">
                  Razdan
                </span>
              </h1>
            </div>

            <p className="text-xl md:text-2xl text-purple-300 font-light">
              Computer Engineering Student | Aspiring Software Developer | AI/ML Enthusiast
            </p>

            <p className="text-lg text-gray-300 max-w-xl leading-relaxed">
              First-year student passionate about web development, machine learning, cloud computing, and cybersecurity.
              Exploring the intersection of technology and innovation.
            </p>

            {/* CTA Buttons */}
            <div className="flex gap-4 pt-4">
              <a
                href="#projects"
                className="px-8 py-3 bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-400 text-white font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg shadow-purple-500/50"
              >
                Explore My Work
              </a>
              <a
                href="#contact"
                className="px-8 py-3 border-2 border-cyan-500 text-cyan-400 hover:bg-cyan-500/10 font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 backdrop-blur"
              >
                Get In Touch
              </a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-8">
              <div className="neon-box p-4 rounded-lg backdrop-blur">
                <div className="text-3xl font-bold text-purple-400">5+</div>
                <div className="text-sm text-gray-400">Projects</div>
              </div>
              <div className="neon-box p-4 rounded-lg backdrop-blur">
                <div className="text-3xl font-bold text-cyan-400">10+</div>
                <div className="text-sm text-gray-400">Skills</div>
              </div>
              <div className="neon-box p-4 rounded-lg backdrop-blur">
                <div className="text-3xl font-bold text-pink-400">100%</div>
                <div className="text-sm text-gray-400">Dedication</div>
              </div>
            </div>
          </div>

          {/* Right Image Gallery */}
          <div className="flex justify-center slide-in-right">
            <div className="relative w-full max-w-sm">
              {/* Image Container with Neon Frame */}
              <div className="relative rounded-2xl overflow-hidden p-1 bg-gradient-to-b from-purple-500 via-pink-500 to-cyan-500 shadow-2xl shadow-purple-500/50">
                <div className="relative w-full aspect-square rounded-2xl overflow-hidden bg-[#0a0a0a]">
                  {images.map((image, index) => (
                    <img
                      key={index}
                      src={image || "/placeholder.svg"}
                      alt={`Yuvraj portrait ${index + 1}`}
                      className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
                        index === currentImageIndex ? "opacity-100" : "opacity-0"
                      }`}
                    />
                  ))}

                  {/* Overlay gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-purple-500/20 to-transparent pointer-events-none"></div>
                </div>
              </div>

              {/* Image indicators */}
              <div className="flex gap-2 justify-center mt-6">
                {images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      index === currentImageIndex ? "w-8 bg-purple-500" : "w-2 bg-gray-600 hover:bg-gray-500"
                    }`}
                    aria-label={`Go to image ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="flex justify-center mt-20 animate-bounce">
          <ChevronDown className="text-purple-400" size={32} />
        </div>
      </div>
    </section>
  )
}
