"use client"

import { useState } from "react"
import { ExternalLink } from "lucide-react"

export default function Projects() {
  const [selectedProject, setSelectedProject] = useState<number | null>(null)

  const projects = [
    {
      id: 1,
      title: "Skin Disease Prediction",
      description:
        "Machine learning model that predicts skin diseases based on image analysis and dataset features using advanced algorithms.",
      tags: ["Python", "Machine Learning", "Data Analysis"],
      color: "from-purple-500 to-pink-500",
    },
    {
      id: 2,
      title: "Employee Salary Hike Prediction",
      description:
        "Predictive ML model analyzing company data to estimate potential salary hikes based on performance metrics and experience.",
      tags: ["Python", "ML", "Data Science"],
      color: "from-cyan-500 to-blue-500",
    },
    {
      id: 3,
      title: "Coming Soon",
      description:
        "More exciting projects are in development. Stay tuned for updates on web development and AI initiatives.",
      tags: ["Innovation", "Future", "Tech"],
      color: "from-pink-500 to-orange-500",
    },
  ]

  return (
    <section id="projects" className="min-h-screen flex items-center py-20 px-6 relative">
      <div className="max-w-7xl w-full mx-auto">
        <div className="space-y-12">
          {/* Section Title */}
          <div className="text-center space-y-4">
            <h2 className="text-5xl md:text-6xl font-bold text-white">
              My <span className="text-orange-400">Projects</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-cyan-500 mx-auto"></div>
          </div>

          {/* Projects Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project, index) => (
              <div
                key={project.id}
                onClick={() => setSelectedProject(selectedProject === project.id ? null : project.id)}
                className="neon-box p-6 rounded-xl backdrop-blur border border-purple-500/30 hover:border-purple-500/60 transition-all duration-300 cursor-pointer group transform hover:scale-105 fade-in-up"
                style={{ animationDelay: `${index * 0.15}s` }}
              >
                <div
                  className={`h-2 w-24 rounded-full bg-gradient-to-r ${project.color} mb-6 group-hover:w-full transition-all duration-300`}
                ></div>
                <h3 className="text-2xl font-bold text-white mb-3">{project.title}</h3>
                <p className="text-gray-300 text-sm leading-relaxed mb-4">{project.description}</p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, i) => (
                    <span
                      key={i}
                      className="text-xs px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full border border-purple-500/30"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {selectedProject === project.id && (
                  <div className="border-t border-purple-500/20 pt-4 mt-4 flex gap-2">
                    <button className="flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors">
                      <ExternalLink size={16} /> View Project
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
