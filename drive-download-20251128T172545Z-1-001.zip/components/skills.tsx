"use client"

import { useState } from "react"

export default function Skills() {
  const [activeTab, setActiveTab] = useState("technical")

  const technicalSkills = [
    { name: "Python", level: 85, category: "Language" },
    { name: "C", level: 80, category: "Language" },
    { name: "Web Development", level: 75, category: "Development" },
    { name: "Machine Learning", level: 70, category: "AI/ML" },
    { name: "Data Analysis (Looker Studio)", level: 80, category: "Analytics" },
    { name: "Cloud Computing", level: 65, category: "Cloud" },
    { name: "MATLAB", level: 75, category: "Tools" },
    { name: "Computer Architecture", level: 70, category: "Fundamentals" },
  ]

  const softSkills = [
    { name: "Problem Solving", level: 90 },
    { name: "Teamwork & Collaboration", level: 88 },
    { name: "Presentation Skills", level: 80 },
    { name: "Active Listening", level: 85 },
    { name: "Critical Thinking", level: 87 },
    { name: "Communication", level: 82 },
  ]

  return (
    <section id="skills" className="min-h-screen flex items-center py-20 px-6 relative">
      <div className="max-w-7xl w-full mx-auto">
        <div className="space-y-12">
          {/* Section Title */}
          <div className="text-center space-y-4">
            <h2 className="text-5xl md:text-6xl font-bold text-white">
              My <span className="text-cyan-400">Skills</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-cyan-500 mx-auto"></div>
          </div>

          {/* Tabs */}
          <div className="flex gap-4 justify-center">
            <button
              onClick={() => setActiveTab("technical")}
              className={`px-8 py-3 rounded-lg font-semibold transition-all duration-300 ${
                activeTab === "technical"
                  ? "bg-gradient-to-r from-purple-600 to-purple-500 text-white shadow-lg shadow-purple-500/50"
                  : "border-2 border-purple-500/50 text-purple-300 hover:border-purple-500"
              }`}
            >
              Technical Skills
            </button>
            <button
              onClick={() => setActiveTab("soft")}
              className={`px-8 py-3 rounded-lg font-semibold transition-all duration-300 ${
                activeTab === "soft"
                  ? "bg-gradient-to-r from-cyan-600 to-cyan-500 text-white shadow-lg shadow-cyan-500/50"
                  : "border-2 border-cyan-500/50 text-cyan-300 hover:border-cyan-500"
              }`}
            >
              Soft Skills
            </button>
          </div>

          {/* Skills Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {(activeTab === "technical" ? technicalSkills : softSkills).map((skill, index) => (
              <div
                key={index}
                className="neon-box p-6 rounded-xl backdrop-blur border border-purple-500/30 fade-in-up hover:border-purple-500/60 transition-all duration-300"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-semibold text-white">{skill.name}</h3>
                  <span className="text-sm font-bold text-transparent bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text">
                    {skill.level}%
                  </span>
                </div>
                <div className="w-full h-3 bg-gradient-to-r from-gray-700 to-gray-600 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full transition-all duration-1000 ease-out"
                    style={{
                      width: `${skill.level}%`,
                      animation: `slideInLeft 0.8s ease-out`,
                    }}
                  ></div>
                </div>
                {activeTab === "technical" && (skill as any).category && (
                  <p className="text-xs text-gray-400 mt-2">{(skill as any).category}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
