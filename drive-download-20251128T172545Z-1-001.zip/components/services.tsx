"use client"

import { Code, Lightbulb, TrendingUp } from "lucide-react"

export default function Services() {
  const services = [
    {
      icon: Code,
      title: "Web Development",
      description: "Building simple, functional, and modern websites with focus on user experience and clean code.",
      color: "from-purple-500 to-pink-500",
    },
    {
      icon: Lightbulb,
      title: "Data Analysis",
      description: "Learning and practicing data analysis using Google Looker Studio to visualize and interpret data.",
      color: "from-cyan-500 to-blue-500",
    },
    {
      icon: TrendingUp,
      title: "Software Development",
      description: "Creating scalable solutions with Python and C, with hands-on experience in various applications.",
      color: "from-pink-500 to-orange-500",
    },
  ]

  return (
    <section id="services" className="min-h-screen flex items-center py-20 px-6 relative">
      <div className="max-w-7xl w-full mx-auto">
        <div className="space-y-12">
          {/* Section Title */}
          <div className="text-center space-y-4">
            <h2 className="text-5xl md:text-6xl font-bold text-white">
              My <span className="text-pink-400">Services</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-cyan-500 mx-auto"></div>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon
              return (
                <div
                  key={index}
                  className="neon-box p-8 rounded-xl backdrop-blur border border-purple-500/30 hover:border-purple-500/60 transition-all duration-300 group cursor-pointer fade-in-up transform hover:scale-105"
                  style={{ animationDelay: `${index * 0.2}s` }}
                >
                  <div
                    className={`w-16 h-16 rounded-lg bg-gradient-to-br ${service.color} p-3 mb-6 group-hover:scale-110 transition-transform`}
                  >
                    <Icon className="w-full h-full text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">{service.title}</h3>
                  <p className="text-gray-300 leading-relaxed">{service.description}</p>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
