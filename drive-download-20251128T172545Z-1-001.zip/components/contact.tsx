"use client"

import { Mail, Phone, MailIcon } from "lucide-react"

export default function Contact() {
  const contactInfo = [
    {
      icon: Mail,
      label: "Email",
      value: "Yuvrajrazdan89@gmail.com",
      href: "mailto:Yuvrajrazdan89@gmail.com",
      color: "from-purple-500 to-pink-500",
    },
    {
      icon: Phone,
      label: "Phone",
      value: "+91 98587 53802",
      href: "tel:+919858753802",
      color: "from-cyan-500 to-blue-500",
    },
  ]

  return (
    <section id="contact" className="min-h-screen flex items-center py-20 px-6 relative">
      <div className="max-w-7xl w-full mx-auto">
        <div className="space-y-12">
          {/* Section Title */}
          <div className="text-center space-y-4">
            <h2 className="text-5xl md:text-6xl font-bold text-white">
              Get In <span className="text-cyan-400">Touch</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-cyan-500 mx-auto"></div>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              I'd love to hear from you! Whether you have a question or just want to connect, feel free to reach out.
            </p>
          </div>

          {/* Contact Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
            {contactInfo.map((item, index) => {
              const Icon = item.icon
              return (
                <a
                  key={index}
                  href={item.href}
                  className="neon-box p-8 rounded-xl backdrop-blur border border-purple-500/30 hover:border-purple-500/60 transition-all duration-300 group cursor-pointer fade-in-up transform hover:scale-105"
                  style={{ animationDelay: `${index * 0.2}s` }}
                >
                  <div
                    className={`w-16 h-16 rounded-lg bg-gradient-to-br ${item.color} p-3 mb-4 group-hover:scale-110 transition-transform`}
                  >
                    <Icon className="w-full h-full text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{item.label}</h3>
                  <p className="text-purple-300 hover:text-purple-200 transition-colors font-medium break-all">
                    {item.value}
                  </p>
                </a>
              )
            })}
          </div>

          <div className="flex justify-center mt-16">
            <a
              href="mailto:Yuvrajrazdan89@gmail.com"
              className="p-6 rounded-full bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-500 hover:to-cyan-500 text-white transition-all duration-300 transform hover:scale-110 shadow-lg shadow-purple-500/50 neon-text"
              title="Send me an email"
            >
              <MailIcon size={40} />
            </a>
          </div>

          {/* Footer Text */}
          <div className="text-center pt-12 border-t border-purple-500/20">
            <p className="text-gray-400">
              Designed & Built with <span className="text-pink-500">❤️</span> by Yuvraj Razdan | © 2025
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
